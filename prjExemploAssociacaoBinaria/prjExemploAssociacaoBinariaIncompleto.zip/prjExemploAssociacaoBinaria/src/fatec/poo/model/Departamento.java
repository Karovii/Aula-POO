package fatec.poo.model;

/**
 *
 * @author Cauã
 */
public class Departamento {
    private String sigla;
    private String nome;
    private Funcionario [] funcionarios; //matriz de objetos / multiplicidade 1..*
    private int numFunc;
    
    public Departamento(String sigla, String nome) {
        this.sigla = sigla;
        this.nome = nome;
        funcionarios = new Funcionario[5];
        numFunc = 0; //indica o primeiro elemento da matriz
    }

    public String getSigla() {
        return sigla;
    }

    public String getNome() {
        return nome;
    }
    
    //tem como parametro de entrada um endereço de um onjeto da classe funcionarioHorista
    //da calsse funcionarioMensalista, e da classe funcioarioComissionado
    public void addFuncionario(Funcionario f){
        funcionarios[numFunc++] = f;
    }
    public void listarFuncionarios(){
        
    }
}
