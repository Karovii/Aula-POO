package fatec.poo.model;

/**
 *
 * @author Cauã
 */
public class PessoaJuridica extends Pessoa {
    private String cgc;
    private double taxaIncentivo;
    
    public PessoaJuridica(String n, String gc, int ai){
        super(n,ai);
        cgc = gc;
    }
    
    public void setTaxaIncentivo(double ti){
        taxaIncentivo = ti;
    }
    
    public String getCgc(){
        return(cgc);
    }
    
    public double getTaxaIncentivo(){
        return(taxaIncentivo);
    }
    
    public double calcBonus(int b){
        return((taxaIncentivo/100 * getTotalCompras()) * (b - getAnoInscricao()));
    }
    
    
    
}
