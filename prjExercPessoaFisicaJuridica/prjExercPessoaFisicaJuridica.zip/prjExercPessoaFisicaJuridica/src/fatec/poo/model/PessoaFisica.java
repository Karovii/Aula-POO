package fatec.poo.model;

/**
 *
 * @author Cauã
 */
public class PessoaFisica extends Pessoa{
    private String cpf;
    private double base;
    
    public PessoaFisica(String n, String c, int ai){
        super(n, ai);
        cpf = c;
    }
    
    public String getCpf(){
        return(cpf);
    }
    
    public void setBase(double b){
        base = b;
    }
    
    public double getBase(){
        return base;
    }
    
    public double calcBonus(int x){
        if(getTotalCompras()>12000){
            return((x - getAnoInscricao())*base);
        }else{
            return 0;
        }
    }
}
