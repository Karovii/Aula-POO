import fatec.poo.model.*;
import java.text.DecimalFormat;
import java.util.Scanner;
/**
 *
 * @author 0030482321011
 */
public class Aplic {
    public static void main(String[] args) {
        String nome, cpf, cgc;
        int anoIn, anoAt;
        double compras, tx, base;
        Scanner entrada = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("#,##0.00");
        
        System.out.println("Insira o ano atual:");
        anoAt = entrada.nextInt();
        System.out.println("Insira o nome da Pessoa Física:");
        nome = entrada.next();
        System.out.println("Insira o CPF:");
        cpf = entrada.next();
        System.out.println("Insira o ano de inscrição:");
        anoIn = entrada.nextInt();
        PessoaFisica objPeFis = new PessoaFisica(nome, cpf, anoIn);
        System.out.println("Insira o valor Base:");
        base = entrada.nextDouble();
        objPeFis.setBase(base);
        
        System.out.println("\n\nInsira o nome da Pessoa Jurídica:");
        nome = entrada.next();
        System.out.println("Insira o CGC:");
        cgc = entrada.next();
        System.out.println("Insira o ano de inscrição:");
        anoIn = entrada.nextInt();      
        PessoaJuridica objPeJur = new PessoaJuridica(nome, cgc, anoIn);
        System.out.println("Insira a Taxa de Incentivo");
        tx = entrada.nextDouble();
        objPeJur.setTaxaIncentivo(tx);
        
        do{
            System.out.println("\nInsira o valor da compra:");
            compras = entrada.nextDouble();
            if(compras>0){
            objPeFis.addCompras(compras);
            objPeJur.addCompras(compras);                
            }
        }while(compras>0);
        
        System.out.println("\n\nPessoa Física");
        System.out.println("Nome: " + objPeFis.getNome());
        System.out.println("CPF: " + objPeFis.getCpf());
        System.out.println("Ano Inscrição: " + objPeFis.getAnoInscricao());
        System.out.println("Compras Totais: " + df.format(objPeFis.getTotalCompras())+ "R$");
        System.out.println("Base: " + df.format(objPeFis.getBase())+"R$");
        System.out.println("Bônus: " + df.format(objPeFis.calcBonus(anoAt))+ "R$");

        System.out.println("\n\nPessoa Jurídica");
        System.out.println("Nome: " + objPeJur.getNome());
        System.out.println("CGC: " + objPeJur.getCgc());
        System.out.println("Ano Inscrição: " + objPeJur.getAnoInscricao());
        System.out.println("Compras Totais: " + df.format(objPeJur.getTotalCompras())+"R$");
        System.out.println("Taxa Incentivo: " + objPeJur.getTaxaIncentivo()+ "%");
        System.out.println("Bônus: " + df.format(objPeJur.calcBonus(anoAt))+ "R$");
        
    }
    
}
