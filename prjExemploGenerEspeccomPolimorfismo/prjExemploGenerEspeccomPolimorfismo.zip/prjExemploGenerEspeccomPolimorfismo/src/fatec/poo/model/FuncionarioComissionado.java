package fatec.poo.model;

/**
 *
 * @author Cauã
 */
public class FuncionarioComissionado extends Funcionario {
    private double salBase, taxaComissao, totalVendas;
    
    public FuncionarioComissionado(int r, String n, String dtAdm, String cr, double tc){
        super(r, n, dtAdm, cr);
        taxaComissao = tc;
    }

    public double getSalBase() {
        return salBase;
    }

    public double getTaxaComissao() {
        return taxaComissao;
    }

    public double getTotalVendas() {
        return totalVendas;
    }

    public void setSalBase(double sb) {
        salBase = sb;
    }
    
    public void addVendas(double av){
        totalVendas += av;
    }
    
    public double calcSalBruto(){
        return(salBase+((taxaComissao/100)*totalVendas));
    }
    
    public double calcSalLiquido(){
        return(calcSalBruto()-calcDesconto()+calcGrat());
    }
    
    public double calcGrat(){
        if(totalVendas<=5000){
            return(0);
        } else if(totalVendas<=10000){
            return(0.03*calcSalBruto());
        }else{
            return(0.05*calcSalBruto());
        }
    }
    
    
    
    
    
    
    
    
}
