import fatec.poo.model.*;
import java.text.DecimalFormat;

/**
 *
 * @author Cauã
 */
public class Aplic {
    public static void main(String[] args) {
        FuncionarioHorista objFuncHor = new FuncionarioHorista(123, "Carlos Silva", "08/10/2015", 28, "Projetista");
        FuncionarioMensalista objFuncMen = new FuncionarioMensalista(1400, 1222, "Renato Silveira", "10/04/2020", "Desenvolvedor");
        DecimalFormat df = new DecimalFormat("#,##0.00");
        FuncionarioComissionado objFuncCom = new FuncionarioComissionado(1010, "Simas Malafaia", "10/04/2024", "Vendedor", 8);
        
        
        
        objFuncHor.setQtdHorTrab(160);
        System.out.println("Nome: " + objFuncHor.getNome());
        System.out.println("Data Admissão: " + objFuncHor.getDtAdmissao());
        System.out.println("Registro: " + objFuncHor.getRegistro());
        System.out.println("Cargo: " + objFuncHor.getCargo());        
        System.out.println("Salário Bruto: " + df.format(objFuncHor.calcSalBruto()) + "R$");
        System.out.println("Gratificação: " + df.format(objFuncHor.calcGrat()) + "R$");
        System.out.println("Descontos: " + df.format(objFuncHor.calcDesconto()) + "R$");
        System.out.println("Salário Liquido: " + df.format(objFuncHor.calcSalLiquido()) + "R$");
        
        objFuncMen.setNumSalMin(3);
        System.out.println("\n\nNome: " + objFuncMen.getNome());
        System.out.println("Data Admissão: " + objFuncMen.getDtAdmissao());
        System.out.println("Registro: " + objFuncMen.getRegistro());
        System.out.println("Cargo: " + objFuncMen.getCargo()); 
        System.out.println("Salário Bruto: "+ df.format(objFuncMen.calcSalBruto()) + "R$");
        System.out.println("Descontos: " + df.format(objFuncMen.calcDesconto()) + "R$");
        System.out.println("Salário Liquido: " + df.format(objFuncMen.calcSalLiquido()) + "R$");
        
        objFuncCom.setSalBase(1500);
        objFuncCom.addVendas(10000);
        System.out.println("\n\nNome: " + objFuncCom.getNome());
        System.out.println("Data Admissão: " + objFuncCom.getDtAdmissao());
        System.out.println("Registro: " + objFuncCom.getRegistro());
        System.out.println("Cargo: " + objFuncCom.getCargo());
        System.out.println("Salário Base: " + df.format(objFuncCom.getSalBase())+"R$");
        System.out.println("Total Vedas: " + objFuncCom.getTotalVendas());
        System.out.println("Taxa Comissão: " + objFuncCom.getTaxaComissao() + "%");
        System.out.println("Gratificação: " + df.format(objFuncCom.calcGrat())+"R$");
        System.out.println("Salário Bruto: " + df.format(objFuncCom.calcSalBruto())+"R$");
        System.out.println("Salário Liquido: " + df.format(objFuncCom.calcSalLiquido())+"R$");

        
    }
    
}
