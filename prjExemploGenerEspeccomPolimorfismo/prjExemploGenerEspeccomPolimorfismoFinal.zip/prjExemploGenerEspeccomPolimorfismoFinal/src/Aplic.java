import fatec.poo.model.*;

/**
 *
 * @author Cauã
 */
public class Aplic {
    public static void main(String[] args) {
        FuncionarioHorista objFuncHor = new FuncionarioHorista(123, "Carlos Silva", "08/10/2015", "Projetista" ,100);
        FuncionarioMensalista objFuncMen = new FuncionarioMensalista(1400, 1222, "Renato Silveira", "10/04/2020", "Desenvolvedor");
        FuncionarioComissionado objFuncCom = new FuncionarioComissionado(5000, "Carlos Almeida", "24/03/2024", "Vendedor", 8);
        
        objFuncHor.setQtdHorTrab(160);
        System.out.println("Nome: " + objFuncHor.getNome());
        System.out.println("Data Admissão: " + objFuncHor.getDtAdmissao());
        System.out.println("Registro: " + objFuncHor.getRegistro());
        System.out.println("Cargo: " + objFuncHor.getCargo());        
        System.out.println("Salário Bruto: " + objFuncHor.calcSalBruto());
        System.out.println("Gratificação: " + objFuncHor.calcGrat());
        System.out.println("Descontos: " + objFuncHor.calcDesconto());
        System.out.println("Salário Liquido: " + objFuncHor.calcSalLiquido());
        
        objFuncMen.setNumSalMin(3);
        System.out.println("\n\nNome: " + objFuncMen.getNome());
        System.out.println("Data Admissão: " + objFuncMen.getDtAdmissao());
        System.out.println("Registro: " + objFuncMen.getRegistro());
        System.out.println("Cargo: " + objFuncMen.getCargo()); 
        System.out.println("Salário Bruto: "+ objFuncMen.calcSalBruto());
        System.out.println("Descontos: " + objFuncMen.calcDesconto());
        System.out.println("Salário Liquido: " + objFuncMen.calcSalLiquido());  
      
        objFuncCom.setSalBase(1400);
        objFuncCom.addVendas(100000);
        System.out.println("\n\nNome: " + objFuncCom.getNome());
        System.out.println("Data Admissão: " + objFuncCom.getDtAdmissao());
        System.out.println("Registro: " + objFuncCom.getRegistro());
        System.out.println("Cargo: " + objFuncCom.getCargo());   
        System.out.println("Salário Base: " + objFuncCom.getSalBase());
        System.out.println("Vendas Totais: " + objFuncCom.getTotalVendas());
        System.out.println("Taxa Comissão: " + objFuncCom.getTaxaComissao() + "%");
        System.out.println("Salário Bruto: " + objFuncCom.calcSalBruto());
        System.out.println("Gratificação: " + objFuncCom.calcGrat());
        System.out.println("Descontos: " + objFuncCom.calcDesconto());
        System.out.println("Salário Liquido: " + objFuncCom.calcSalLiquido());
        
        
        
    }
    
}
