package fatec.poo.model;

/**
 *
 * @author Cauã
 */
public class FuncionarioComissionado extends Funcionario {
    private double salBase;
    private double  taxaComissao;
    private double totalVendas;
    
    
    public FuncionarioComissionado(int r, String n, String dtAdm, String cr, double tc){
        super(r, n, dtAdm, cr);
        taxaComissao = tc;
    }

    public double getSalBase() {
        return salBase;
    }

    public void setSalBase(double sb) {
        salBase = sb;
    }

    public double getTotalVendas() {
        return totalVendas;
    }

    public double getTaxaComissao() {
        return (taxaComissao);
    }
    
    public void addVendas(double av){
        totalVendas += av;
    }
    
    public double calcSalBruto(){
        return(salBase + ((taxaComissao/100)*totalVendas));
    }
    
    public double calcGrat(){
    if (totalVendas<=5000){
        return(0);
    }
    else if(totalVendas<=10000){
        return(calcSalBruto()*0.03);
    }else{
        return(calcSalBruto()*0.05);
    }
    }
    
    public double calcSalLiquido(){
          return(calcSalBruto() + calcGrat() - super.calcDesconto()); 
    }
    
}
