package fatec.poo.model;

/**
 *
 * @author Cauã
 */
public class FuncionarioHorista extends Funcionario{
    private double valHorTrab;
    private int qtdHorTrab;
    
    public FuncionarioHorista (int r, String n, String dtAdm, String cr, double vht){
        super(r, n, dtAdm, cr);
        valHorTrab = vht;
    }

    public void setQtdHorTrab(int qht) {
        qtdHorTrab = qht;
    }
    
    public double calcSalBruto(){
        return(valHorTrab * qtdHorTrab);
    }
    
    public double calcGrat(){
        return(0.075 * calcSalBruto());
    }
    
    public double calcSalLiquido(){
    return(calcSalBruto() - calcDesconto() + calcGrat());
}

}
